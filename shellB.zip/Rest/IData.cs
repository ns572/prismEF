﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using entitysample;

namespace Rest
{
   public  interface IData
    {
         List<T> retstudent<T>();

         List<T> retsingle<T>(int rollno);
        void insertstudent(int rollno, string fname, string lname, int age);

        void updatestudent(int rollno, string fname);

        void deletestudent(int rollno);
    }

}
