﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using entitysample;
using TableLibrary;

namespace Rest
{
    //public class Table
    //{
    //    public int rollno { get; set; }
    //    public string fname { get; set; }
    //    public string lname { get; set; }
    //    public Nullable<int> age { get; set; }

    //}


    //List<T> retstudent();

    //List<T> retsingle(int rollno);

    //void insertstudent(int rollno, string fname, string lname, int age);

    //void updatestudent(int rollno, string fname);

    //void deletestudent(int rollno);


    public class Class1:IDataSample<Table>

    { 


        static HttpClient client = new HttpClient();
        TablesCollection _Tables = new TablesCollection();


        class TablesCollection : ObservableCollection<Table>
        {
            public void CopyFrom(IEnumerable<Table> Tables)
            {
                this.Items.Clear();
                foreach (var p in Tables)
                {
                    this.Items.Add(p);
                }

                this.OnCollectionChanged(
                    new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
            }
        }


        public Class1()
        {

            client.BaseAddress = new Uri("http://localhost:3000/");

            client.DefaultRequestHeaders.Accept.Clear();

            client.DefaultRequestHeaders.Accept.Add(
            new MediaTypeWithQualityHeaderValue("application/json"));

            try
            {


                //  GetTablesAsync()

            }



            catch (AggregateException e)
            {
                // MessageBox.Show(e.StackTrace);
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            Console.ReadLine();
            

        }



        /*
                static async Task<Uri> CreateTableAsync(Table prod)
                {
                    HttpResponseMessage response = await client.PostAsJsonAsync("/istudent", prod);
                    response.EnsureSuccessStatusCode();

                    return response.Headers.Location;
                }
        */


        public List<Table> retstudent()
        {

            HttpResponseMessage response =  client.GetAsync("/").Result;

            List<Table> pro = new List<Table>();

            //content.ReadAsStringAsync().Result

            if (response.IsSuccessStatusCode)
            {
                var Tables = response.Content.ReadAsAsync<IEnumerable<Table>>().Result;
                //     dataGrid.ItemsSource = Tables;

              

                foreach (Table p in Tables)
                {
                    pro.Add(p);
                }

                

            }

            return pro;

        }



       /* public MainWindow()
        {
          //  InitializeComponent();

            Bindprod();

        }*/

        public void insertstudent(int rn,string fn,string ln,int ag)
        {



            Table prod = new Table { rollno = rn, fname = fn.Split('\n')[0], lname = ln.Split('\n')[0], age = ag };

            HttpResponseMessage response = client.PostAsJsonAsync("/istudent", prod).Result;



            if (response.IsSuccessStatusCode)
            {


             //   MessageBox.Show("student added");

                //GetTablesAsync();

            }

            else
            {
             //   MessageBox.Show("Error Code" + response.StatusCode + " : Message - " + response.ReasonPhrase);

            }



        }



        public void updatestudent(int rn,string fn)
        {

            Table prod = new Table { rollno = rn, fname = fn.Split('\n')[0] ,lname="",age=0};

            HttpResponseMessage response = client.PostAsJsonAsync("/update/" + prod.rollno, prod).Result;


            if (response.IsSuccessStatusCode)
            {


              //  MessageBox.Show("student updated");

              //  GetTablesAsync();

            }

            else
            {
                //MessageBox.Show("Error Code" + response.StatusCode + " : Message - " + response.ReasonPhrase);

            }


        }

        public List<Table> retsingle(int rollno)
        {


          //  Table prod = new Table { rollno = rollno};

            HttpResponseMessage response =  client.GetAsync("/search/" + rollno).Result;
            List<Table> pro = new List<Table>();

            if (response.IsSuccessStatusCode)
            {

               // MessageBox.Show("student found");

                var Tables =  response.Content.ReadAsAsync<IEnumerable<Table>>().Result;

                // dataGrid.ItemsSource = Tables;

                foreach (Table p in Tables)
                {
                    pro.Add(p);
                }


            }

            else
            {
              //  MessageBox.Show("Error Code" + response.StatusCode + " : Message - " + response.ReasonPhrase);

            }

            return pro;

        }

        public void deletestudent(int rn)
        {
           // Table prod = new Table { rollno = int.Parse(t1.Text), fname = t2.Text.Split('\n')[0], lname = t3.Text.Split('\n')[0] };

            HttpResponseMessage response = client.DeleteAsync("/delete/" + rn).Result;

            if (response.IsSuccessStatusCode)
            {

             //   MessageBox.Show("student deleted");

             //   GetTablesAsync();

            }

            else
            {
               // MessageBox.Show("Error Code" + response.StatusCode + " : Message - " + response.ReasonPhrase);

            }


        }

        
    }
}