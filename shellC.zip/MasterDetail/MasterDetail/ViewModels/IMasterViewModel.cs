﻿using Prism.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDetail.ViewModels
{
    public interface IMasterViewModel
    { String ViewModelName { get; set; }

        DelegateCommand<object> MasterButton_Command { get; set; }
    }
}
