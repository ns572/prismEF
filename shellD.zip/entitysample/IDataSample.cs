﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entitysample
{
   public interface IDataSample<T>
    {
        List<T> retstudent();

        List<T> retsingle(int rollno);

        void insertstudent(int rollno, string fname, string lname, int age);

        void updatestudent(int rollno, string fname);

        void deletestudent(int rollno);

      /*  public class Table
        {
            public int rollno { get; set; }
            public string fname { get; set; }
            public string lname { get; set; }
            public int age { get; set; }

        }
        */

    }
}
