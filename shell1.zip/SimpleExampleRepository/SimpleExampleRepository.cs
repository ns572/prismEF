﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimpleExampleModel;
using entitysample;
using TableLibrary;
using Factory;

namespace SimpleExampleRepository
{
    public class SimpleExampleRepository:ISimpleExampleRepository

    {


        public string GetNameForMasterViewModel()
        {
            return "SimpleExampleRepository.GetNameForMasterViewModel() returning 'MasterViewModel'";
        }

        public List<Table> GetTableForDetailViewModel()
        {
            //  return "SimpleExampleRepository.GetNameForDetailViewModel() returning 'DetailViewModel'";



            SampleFactory fact = new SampleFactory();

            IDataSample<Table> pro = fact.getservice("no");

            return pro.retstudent();
           // return null;

        }

        //public List<Table> InTableForDetailViewModel()
        //{
        //    //  return "SimpleExampleRepository.GetNameForDetailViewModel() returning 'DetailViewModel'";



        //    SampleFactory fact = new SampleFactory();

        //    IDataSample<Table> pro = fact.getservice("yes");

        //    return pro.retstudent();
        //    // return null;

        //}



        public string GetNewName()
        {
            return "nikhil";
        }


    }
}
