﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Rest;
//using entitysample.Table;
using TableLibrary;

namespace entitysample
{
    public class Program:IDataSample<Table>
    {

     /*   public partial class Table
        {
            public int rollno { get; set; }
            public string fname { get; set; }
            public string lname { get; set; }
            public Nullable<int> age { get; set; }
        }
        */


        //public List<int> retstudent(int a)
        //{

        //    using (var context = new studentdbEntities())
        //    {
        //        // context.Tables student = new 


        //        //department.Name = "Support";


        //        var L2EQuery = from st in context.Tables.AsEnumerable()                        // where st.rollno == 1
        //                       select st;
        //        //  IList<Table> lst = new List<Table>();

        //        var student = L2EQuery.ToList<Table>();
        //        //  lst  = student.ToList<>();
        //        List<int> tset = new List<int>();
        //        tset.Add(1);

        //        return tset;

        //    }


        //}

        public List<Table> retstudent()
        {

            using (var context = new studentdbEntities())
            {
                // context.Tables student = new 


                //department.Name = "Support";


                var L2EQuery = from st in context.Tables                        // where st.rollno == 1
                               select st;
                //  IList<Table> lst = new List<Table>();

                var student = L2EQuery.ToList<Table>();
                //  lst  = student.ToList<>();
               // List<int> tset = new List<int>();
               // tset.Add(1);

                return student;

            }


        }




        public List<Table> retsingle(int rollno)
        {

            using (var context = new studentdbEntities())
            {
                //  context.Tables student = new 


                //department.Name = "Support";


                var L2EQuery = from st in context.Tables.AsEnumerable()
                               where st.rollno == rollno
                               select st;
                //    List<Table> student = new List<Table>();
                /* foreach (var std in L2EQuery)
                 {
                     Table t = new Table();

                     t.

                    student.Add(std);
                 }*/

                var student = L2EQuery.ToList<Table>();

                return student;

            }

        }





        public void insertstudent(int rollno, string fname, string lname, int age)
        {

            using (var context = new studentdbEntities())
            {
                // context.Tables student = new 


                //department.Name = "Support";

                Table t = new Table();

                t.rollno = rollno;
                t.fname = fname;
                t.lname = lname;
                t.age = age;

                context.Tables.Add(t);

                context.SaveChanges();

                /*  var L2EQuery = from st in context.Tables
                                 where st.rollno == 1
                                 select st;

                  var student = L2EQuery.FirstOrDefault<Table>();*/

                //   return student.fname;

            }


        }

        public void updatestudent(int rollno, string fname)
        {

            using (var context = new studentdbEntities())
            {
                // context.Tables student = new 


                //department.Name = "Support";

                Table t = context.Tables.FirstOrDefault(d => d.rollno == rollno);

                // t.rollno = rollno;
                t.fname = fname;
                // t.lname = lname;
                // t.age = age;

                // context.Tables.Add(t);

                context.SaveChanges();

                /*  var L2EQuery = from st in context.Tables
                                 where st.rollno == 1
                                 select st;

                  var student = L2EQuery.FirstOrDefault<Table>();*/

                //   return student.fname;

            }
        }

        public void deletestudent(int rollno)
        {

            using (var context = new studentdbEntities())
            {
                // context.Tables student = new 


                //department.Name = "Support";

                Table t = context.Tables.FirstOrDefault(d => d.rollno == rollno);

                // t.rollno = rollno;
                //       t.fname = fname;
                // t.lname = lname;
                // t.age = age;

                context.Tables.Remove(t);

                // context.Tables.Add(t);

                context.SaveChanges();

               
            }


        }


        static void Main(string[] args)
        {


        }

        //public IEnumerator GetEnumerator()
        //{
        //    throw new NotImplementedException();
        //}

        //public List<T> retstudent<T>()
        //{
        //    throw new NotImplementedException();
        //}
    }
}

