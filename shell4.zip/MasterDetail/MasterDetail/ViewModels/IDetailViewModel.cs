﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDetail.ViewModels
{
    public interface IDetailViewModel
    {
        
        
            String ViewModelName { get; set; }
        
    }
}
