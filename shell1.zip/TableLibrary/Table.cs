﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableLibrary
{
    public class Table
    {
        public int rollno { get; set; }
        public string fname { get; set; }
        public string lname { get; set; }
        public Nullable<int> age { get; set; }

    }
}
