﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using entitysample;
using Rest;
using TableLibrary;


namespace Factory
{
    public class SampleFactory
    {

        public IDataSample<Table> getservice(String running)
        {
            if (running == null)
            {
                return null;
            }
            if (running.Equals("no"))
            {
                return new Program();
           
            }
            else if (running.Equals("yes"))
            {
                return  new Class1();
              //  IDataSample<entitysample.Table> i = c;
                 

            }
            
            return null;
        }


    }
}
