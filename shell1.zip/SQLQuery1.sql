﻿insert into [dbo].[Table] values(4,'AASIF','HUSSAIN',20);
