﻿using Prism.Commands;
using SimpleExampleModel;
using SimpleExampleRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimpleExampleMessages;
using Prism.Events;
using entitysample;
using SimpleExampleMeesages;

namespace MasterDetail.ViewModels
{
   public  class MasterViewModel:IMasterViewModel
    {
        
            public String ViewModelName { get; set; }

            public String rn { get; set; }

            public String fn { get; set; }
            
            public String ln { get; set; }

            public String ag { get; set; }


        public DelegateCommand<object> MasterButton_Command { get; set; }

        public DelegateCommand<object> Update_Command { get; set; }

        public DelegateCommand<object> Delete_Command { get; set; }

        private IEventAggregator eventAggregator;
           
            public MasterViewModel(SimpleExampleService service, IEventAggregator eventAggregator)
            {
                this.eventAggregator = eventAggregator;
                this.ViewModelName = service.GetNameForMasterViewModel();

            MasterButton_Command = new DelegateCommand<object>(MasterButtonCommand_Handler);

            Update_Command = new DelegateCommand<object>(UpdateCommand_Handler);

            Delete_Command = new DelegateCommand<object>(DeleteCommand_Handler);

        }

        private void MasterButtonCommand_Handler(object commandParameter)
        {
            /*( SimpleExampleRepository.SimpleExampleRepository repository = new SimpleExampleRepository.SimpleExampleRepository();
             SimpleExampleService service=new SimpleExampleService(repository);
             this.MasterNewName(service, 1);*/


            Program pro = new Program();

            pro.insertstudent(int.Parse(rn),fn,ln,int.Parse(ag));

            eventAggregator.GetEvent<ChangeLabelEvent>().Publish("hai");

            eventAggregator.GetEvent<ChangeNameEvent>().Publish(fn);

        }


        private void UpdateCommand_Handler(object commandParameter)
        {
            /*( SimpleExampleRepository.SimpleExampleRepository repository = new SimpleExampleRepository.SimpleExampleRepository();
             SimpleExampleService service=new SimpleExampleService(repository);
             this.MasterNewName(service, 1);*/


            Program pro = new Program();

            pro.updatestudent(int.Parse(rn), fn);

          //  eventAggregator.GetEvent<ChangeLabelEvent>().Publish("hai");

            eventAggregator.GetEvent<ChangeNameEvent>().Publish(fn);

        }


        private void DeleteCommand_Handler(object commandParameter)
        {
            /*( SimpleExampleRepository.SimpleExampleRepository repository = new SimpleExampleRepository.SimpleExampleRepository();
             SimpleExampleService service=new SimpleExampleService(repository);
             this.MasterNewName(service, 1);*/


            Program pro = new Program();

            pro.deletestudent(int.Parse(rn));

            //  eventAggregator.GetEvent<ChangeLabelEvent>().Publish("hai");

           // eventAggregator.GetEvent<ChangeNameEvent>().Publish(fn);

        }


    }

}
     /*   public void MasterNewName(SimpleExampleService service,int n)
        {
            this.ViewModelName = service.GetNewName();

            this.ViewModelName = "";

        }*/
