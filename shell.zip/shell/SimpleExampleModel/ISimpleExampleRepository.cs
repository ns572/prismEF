﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using entitysample;

namespace SimpleExampleModel
{
  public interface ISimpleExampleRepository
    {
        string GetNameForMasterViewModel();
        List<Table> GetTableForDetailViewModel();
       // string GetNewName();
    }
}

