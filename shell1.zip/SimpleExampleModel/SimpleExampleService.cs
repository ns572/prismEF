﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using entitysample;
using TableLibrary;

namespace SimpleExampleModel
{
    public class SimpleExampleService :ISimpleExampleService
    {
        private ISimpleExampleRepository repository;

        public SimpleExampleService(ISimpleExampleRepository repository)
        {
            this.repository = repository;
        }

        public string GetNameForMasterViewModel()
        {
            return repository.GetNameForMasterViewModel();
        }

        public List<Table> GetTableForDetailViewModel()
        {
            return repository.GetTableForDetailViewModel();
        }

        /*public string GetNewName()
        {
            return repository.GetNewName();
        }*/
    }
}
