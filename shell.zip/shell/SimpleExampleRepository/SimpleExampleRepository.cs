﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimpleExampleModel;
using entitysample;

namespace SimpleExampleRepository
{
    public class SimpleExampleRepository:ISimpleExampleRepository

    {


        public string GetNameForMasterViewModel()
        {
            return "SimpleExampleRepository.GetNameForMasterViewModel() returning 'MasterViewModel'";
        }

        public List<Table> GetTableForDetailViewModel()
        {
            //  return "SimpleExampleRepository.GetNameForDetailViewModel() returning 'DetailViewModel'";

            Program pro = new Program();

            return pro.retstudent();
           
        }

        public string GetNewName()
        {
            return "nikhil";
        }


    }
}
