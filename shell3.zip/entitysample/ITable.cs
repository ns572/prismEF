﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entitysample
{
    public interface ITable
    {
        int rollno { get; set; }
        string fname { get; set; }
        string lname { get; set; }
        Nullable<int> age { get; set; }

    }
}
