﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entitysample
{
   public  class Program
    {

        public List<Table> retstudent()
        {

            using (var context = new studentdbEntities())
            {
                // context.Tables student = new 


                //department.Name = "Support";


                var L2EQuery = from st in context.Tables
                              // where st.rollno == 1
                               select st;

                var student = L2EQuery.ToList<Table>();

                return student;

            }


        }


        public List<Table> retsingle(int rollno)
        {

            using (var context = new studentdbEntities())
            {
                // context.Tables student = new 


                //department.Name = "Support";


                var L2EQuery = from st in context.Tables
                                   where st.rollno == rollno
                               select st;

                var student = L2EQuery.ToList<Table>();

                return student;

            }


        }


        public void insertstudent(int rollno,string fname,string lname,int age)
        {

            using (var context = new studentdbEntities())
            {
                // context.Tables student = new 


                //department.Name = "Support";

                Table t = new Table();

                t.rollno = rollno;
                t.fname = fname;
                t.lname = lname;
                t.age = age;

                context.Tables.Add(t);

                context.SaveChanges();

              /*  var L2EQuery = from st in context.Tables
                               where st.rollno == 1
                               select st;

                var student = L2EQuery.FirstOrDefault<Table>();*/

             //   return student.fname;

            }


        }

        public void updatestudent(int rollno, string fname)
        {

            using (var context = new studentdbEntities())
            {
                // context.Tables student = new 


                //department.Name = "Support";

                Table t = context.Tables.FirstOrDefault(d => d.rollno == rollno);

                // t.rollno = rollno;
                t.fname = fname;
                // t.lname = lname;
                // t.age = age;

                // context.Tables.Add(t);

                context.SaveChanges();

                /*  var L2EQuery = from st in context.Tables
                                 where st.rollno == 1
                                 select st;

                  var student = L2EQuery.FirstOrDefault<Table>();*/

                //   return student.fname;

            }
        }

            public void deletestudent(int rollno)
            {

            using (var context = new studentdbEntities())
            {
                // context.Tables student = new 


                //department.Name = "Support";

                Table t = context.Tables.FirstOrDefault(d => d.rollno == rollno);

                // t.rollno = rollno;
                //       t.fname = fname;
                // t.lname = lname;
                // t.age = age;

                context.Tables.Remove(t);

                // context.Tables.Add(t);

                context.SaveChanges();

                /*  var L2EQuery = from st in context.Tables
                                 where st.rollno == 1
                                 select st;

                  var student = L2EQuery.FirstOrDefault<Table>();*/

                //   return student.fname;

            }


        }


        static void Main(string[] args)
        {

            
        }
    }
}
