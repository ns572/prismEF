﻿using SimpleExampleModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimpleExampleMessages;
using Prism.Events;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using SimpleExampleMeesages;
using entitysample;
using MasterDetail;
using Prism.Commands;

namespace MasterDetail.ViewModels
{
    public class DetailViewModel : IDetailViewModel, INotifyPropertyChanged
    {
        private IEventAggregator eventAggregator;
      //  public String ViewModelName { get; set; }
        public event PropertyChangedEventHandler PropertyChanged;

        public DelegateCommand Search_Command { get; set; }

        private string viewModelName;

        public String rn { get; set; }

        private List<Table> records;

        private List<Table> record;

        private string fn="meeeeusaaa";


        public List<Table> Records
        {
            get { return records; }

            set
            {
                //  if(records)
                records = value;

                NotifyPropertyChanged("Records");

            }

        }

        public List<Table> Record
        {
            get { return record; }

            set
            {
                //  if(records)
                record = value;

                NotifyPropertyChanged("Record");

            }

        }

        public string ViewModelName
        {
            get { return viewModelName; }
            set
            {
                if (viewModelName != value)
                {
                    viewModelName = value;
                    NotifyPropertyChanged();
                }
            }
        }

        public string Fn
        {
            get { return fn; }
            set
            {
                if (fn != value)
                {
                    fn = value;
                    NotifyPropertyChanged();
                }
            }
        }

        protected void NotifyPropertyChanged([CallerMemberName]string caller = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(caller));
            }
        }

        public DetailViewModel(SimpleExampleService service, IEventAggregator eventAggregator)
        {
            this.eventAggregator = eventAggregator;

            this.Records = service.GetTableForDetailViewModel();

            Search_Command = new DelegateCommand(SearchCommand_Handler);

            // MasterDetail.Views.DetailView.LoadedEvent=

            this.eventAggregator.GetEvent<ChangeLabelEvent>().Subscribe(onChangeLabelEvent);

            this.eventAggregator.GetEvent<ChangeNameEvent>().Subscribe(onChangeNameEvent);

        }


        private void SearchCommand_Handler()
        {
            /*( SimpleExampleRepository.SimpleExampleRepository repository = new SimpleExampleRepository.SimpleExampleRepository();
             SimpleExampleService service=new SimpleExampleService(repository);
             this.MasterNewName(service, 1);*/


            Program pro = new Program();

            this.Record=pro.retsingle(int.Parse(rn));

        //    eventAggregator.GetEvent<ChangeLabelEvent>().Publish("hai");

          //  eventAggregator.GetEvent<ChangeNameEvent>().Publish(fn);

        }



        private void onChangeLabelEvent(string msg)
        {
            ViewModelName = msg;
        }

        private void onChangeNameEvent(string msg)
        {
            Fn= msg;
        }


    }
}
