﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimpleExampleModel;
using entitysample;
using TableLibrary;
using Factory;
using Rest;

namespace SimpleExampleRepository
{
    public class SimpleExampleRepository:ISimpleExampleRepository

    {



        static SampleFactory fact = new SampleFactory();

        public static Class1 restc = new Class1();

        static string choice = restc.ping();

        int cl = restc.clearreq();

        int cr = restc.createclient();

        IDataSample<Table> pro = fact.getservice(choice);


        public string GetNameForMasterViewModel()
        {
            return "SimpleExampleRepository.GetNameForMasterViewModel() returning 'MasterViewModel'";
        }

        public List<Table> GetTableForDetailViewModel()
        {
            //  return "SimpleExampleRepository.GetNameForDetailViewModel() returning 'DetailViewModel'";





            return pro.retstudent();
           // return null;

        }

        public List<Table> GetSingleForDetailViewModel(int rn)
        {
            //  return "SimpleExampleRepository.GetNameForDetailViewModel() returning 'DetailViewModel'";



            //SampleFactory fact = new SampleFactory();

            //IDataSample<Table> pro = fact.getservice("yes");

            return pro.retsingle(rn);
            // return null;

        }


        public void InsertTableForDetailViewModel(int rn,string fn,string ln,int ag)
        {
            //  return "SimpleExampleRepository.GetNameForDetailViewModel() returning 'DetailViewModel'";



            //SampleFactory fact = new SampleFactory();

            //IDataSample<Table> pro = fact.getservice("yes");

            pro.insertstudent(rn,fn,ln,ag);

           // return pro.retstudent();
            // return null;

        }


        public void UpdateTableForDetailViewModel(int rn, string fn)
        {
            //  return "SimpleExampleRepository.GetNameForDetailViewModel() returning 'DetailViewModel'";



            //SampleFactory fact = new SampleFactory();

            //IDataSample<Table> pro = fact.getservice("yes");

            pro.updatestudent(rn, fn);

           // return pro.retstudent();
            // return null;

        }


        public void DeleteTableForDetailViewModel(int rn)
        {
            //  return "SimpleExampleRepository.GetNameForDetailViewModel() returning 'DetailViewModel'";



            //SampleFactory fact = new SampleFactory();

            //IDataSample<Table> pro = fact.getservice("yes");

            pro.deletestudent(rn);

         //   return pro.retstudent();
            // return null;

        }



        public string GetNewName()
        {
            return "nate";
        }


    }
}
